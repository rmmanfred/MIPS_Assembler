//readme.txt
This submission doesn't seem to correctly handle bne and beq 
instructions. Specifically addresses of label to branch to.
It also doesn't finish the line for some reason. This should be 
sorted up by the final
-Ross Manfred <rmm26079>
