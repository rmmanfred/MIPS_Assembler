readme.txt
Couldn't grasp how to handle consecutive asciiz data fields. If a string is terminated on a new line then the rest of the line contains 0s which appears to be wrong in some instances
